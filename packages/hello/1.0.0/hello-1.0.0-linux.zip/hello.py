print("""
Congratulations!

If you are reading this message, ZAP successfully:

- Downloaded the package
- Verified its integrity
- Installed it
- Created a launcher
- Started the application

Everything is working correctly.
""")
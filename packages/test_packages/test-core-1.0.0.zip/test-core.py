import os

print("TEST-CORE: OK")
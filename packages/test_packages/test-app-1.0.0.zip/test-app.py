import os

print("TEST-APP: Looking for test-lib in PATH...")

result = os.system("test-lib")

if result != 0:
    print("TEST-APP: ERROR - test-lib was not found or failed.")
    raise SystemExit(1)

print("TEST-APP: dependency test-lib OK")
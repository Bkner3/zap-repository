import os

print("TEST-LIB: Looking for test-core in PATH...")

result = os.system("test-core")

if result != 0:
    print("TEST-LIB: ERROR - test-core was not found or failed.")
    raise SystemExit(1)

print("TEST-LIB: dependency test-core OK")